﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gyakorlas_desktop
{
    internal class Sorsolas
    {
        public int szam;
        public int db;

        public Sorsolas(int szam, int db)
        {
            this.szam = szam;
            this.db = db;
        }
    }
}
